#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>

using namespace std;
using namespace sf;

const float cellsize = 140.0f; 

int rows = 7; 
int cols = 9;

Texture candytextures[8];

const int speacialcandy = 6;
const int colourBomb = 7;

void removeMatches(int array[][9]);
bool hasMatches(int array[][9]);
void initialiseboard(int array[7][9]);
void drawboard(RenderWindow& window, int array[][9], int selectedRow, int selectedCol);
bool valid(int a[][9], int row1, int col1, int row2, int col2);
void refill(RenderWindow& window, int a[][9]);
void reshuffleBoard(int array[][9]);
bool swapCandies(RenderWindow& window, int array[][9], int& selectedRow, int& selectedCol, int targetRow, int targetCol, int& moves, Text& movesText, int& score, Text& scoreText);

int main() {
    RenderWindow window(VideoMode(1800, 1000), "CANDY CRUSH SAGA", Style::Titlebar | Style::Close | Style::Resize);
    window.setFramerateLimit(60);
    Event ev;

    Font font;
    if (!font.loadFromFile("fonts/Pacifico.ttf")) {
        cout << "error";
    }

    int score = 0;
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(60);
    scoreText.setFillColor(Color::Yellow);
    scoreText.setPosition(1350, 350);
    scoreText.setOutlineColor(Color::White);
    scoreText.setOutlineThickness(2);
    scoreText.setString("Score: " + to_string(score));

    int moves = 25;
    Text movesText;
    movesText.setFont(font);
    movesText.setCharacterSize(60);
    movesText.setFillColor(Color::Yellow);
    movesText.setPosition(1350, 450);
    movesText.setOutlineColor(Color::White);
    movesText.setOutlineThickness(2);
    movesText.setString("Moves: " + to_string(moves));

    int target = 200;
    Text targettext;
    targettext.setFont(font);
    targettext.setCharacterSize(80);
    targettext.setFillColor(Color::Blue);
    targettext.setPosition(1350, 750);
    targettext.setOutlineColor(Color::White);
    targettext.setOutlineThickness(2);
    targettext.setString("Target: " + to_string(target));

    Music music;
    if (!music.openFromFile("sounds/candycrushtone.ogg")) {
        cout << "Error";
    }
    music.play();
    music.setLoop(true);

    SoundBuffer candysoundBuffer;
    if (!candysoundBuffer.loadFromFile("sounds/sound.wav")) {
        cerr << "Error loading sound file!" << endl;
        return -1;
    }

    Sound crushsound;
    crushsound.setBuffer(candysoundBuffer);

    Texture bg;
    if (!bg.loadFromFile("images/bg.jpg")) {
        return 1;
    }
    Sprite background(bg);
    float scaleX = static_cast<float>(window.getSize().x) / background.getTexture()->getSize().x;
    float scaleY = static_cast<float>(window.getSize().y) / background.getTexture()->getSize().y;
    background.setScale(scaleX, scaleY);

    int gameboard[7][9]; 
    int selectedRow = -1;
    int selectedCol = -1;

    for (int i = 0; i < 7; i++) {
        string filename = "images/candy" + to_string(i) + ".jpeg";
        candytextures[i].loadFromFile(filename);
    }
    candytextures[7].loadFromFile("images/candy7.jpg");

    Clock timer;
    const Time totalTime = seconds(11);
    float timeLeft = totalTime.asSeconds();

    Text timertext;
    timertext.setFont(font);
    timertext.setCharacterSize(70);
    timertext.setPosition(1350, 550);
    timertext.setOutlineThickness(2);
    timertext.setOutlineColor(Color::Black);

    Text timeDisplay;
    timeDisplay.setFont(font);
    timeDisplay.setCharacterSize(60);
    timeDisplay.setFillColor(Color::Yellow);
    timeDisplay.setPosition(1350, 650);
    timeDisplay.setOutlineColor(Color::White);
    timeDisplay.setOutlineThickness(2);

    initialiseboard(gameboard);

    while (window.isOpen()) {
        Time elapsed = timer.getElapsedTime();
        timeLeft = totalTime.asSeconds() - elapsed.asSeconds();

        if (timeLeft <= 0) {
            timer.restart();
            moves--;
            movesText.setString("Moves: " + to_string(moves));
            score -= 10;
            scoreText.setString("Score:" + to_string(score));
            timeLeft = totalTime.asSeconds();
            if (moves <= 0) {
                window.close();
                break;
            }
        }

        timertext.setString("Time: " + to_string(static_cast<int>(timeLeft)) + "s");

        window.clear();
        window.draw(background);
        window.draw(timertext);
        window.draw(scoreText);
        window.draw(movesText);
        window.draw(targettext);
        window.draw(timeDisplay);
        drawboard(window, gameboard, selectedRow, selectedCol);

        while (window.pollEvent(ev)) {
            switch (ev.type) {
            case Event::Closed:
                window.close();
                break;
            case Event::KeyPressed:
                if (ev.key.code == Keyboard::Escape)
                    window.close();
                break;

            case Event::MouseButtonPressed:
                if (ev.mouseButton.button == Mouse::Left) {
                    int mouseX = ev.mouseButton.x;
                    int mouseY = ev.mouseButton.y;

                    int gridX = mouseX / cellsize;
                    int gridY = mouseY / cellsize;

                    if (selectedRow == -1 && selectedCol == -1) {
                        selectedRow = gridY;
                        selectedCol = gridX;
                    }
                    else {
                        bool check = swapCandies(window, gameboard, selectedRow, selectedCol, gridY, gridX, moves, movesText, score, scoreText);
                        if (check)
                        {
                            crushsound.play();
                        }

                        removeMatches(gameboard);

                        refill(window, gameboard);
                        selectedRow = -1;
                        selectedCol = -1;
                    }
                }
                break;
            }
        }

        if (moves == 0 || score >= 200) {
            cout << (score >= 200 ? "You won!" : "Game Over") << endl;
            window.close();
            break;
        }

        window.display();
    }

    return 0;
}


void removeMatches(int array[][9]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int h_count = 1;
            for (int k = j + 1; k < cols && array[i][k] == array[i][j]; k++) {
                h_count++;
            }

            int v_count = 1;
            for (int k = i + 1; k < rows && array[k][j] == array[i][j]; k++) {
                v_count++;
            }
            int d_count = 1;
            for (int k = 1; i + k < rows && j + k < cols && array[i + k][j + k] == array[i][j]; k++) {
                d_count++;
            }



            if (h_count == 4) {

                array[i][j] = speacialcandy;
            }
            else if (h_count == 5) {

                array[i][j] = colourBomb;
            }
            else if (v_count == 4) {

                array[i][j] = speacialcandy;
            }
            else if (v_count == 5) {

                array[i][j] = colourBomb;
            }
            else if (h_count >= 3) {

                for (int k = j; k < j + h_count; k++) {
                    array[i][k] = rand() % 6;
                }
            }
            else if (v_count >= 3) {

                for (int k = i; k < i + v_count; k++) {
                    array[k][j] = rand() % 6;
                }
            }
            else if (d_count == 3 || d_count >= 3) {

                for (int k = 0; k < 3 && i + k < rows && j + k < cols; k++) {
                    array[i + k][j + k] = rand() % 6;
                }

            }
        }
    }
}



bool hasMatches(int array[][9]) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int h_count = 1;
            for (int k = j + 1; k < cols && array[i][k] == array[i][j]; k++) {
                h_count++;
            }
            int v_count = 1;
            for (int k = i + 1; k < cols && array[k][j] == array[i][j]; k++) {
                v_count++;
            }
            int d_count = 1;
            for (int k = 1; i + k < rows && j + k < cols && array[i + k][j + k] == array[i][j]; k++) {
                d_count++;
            }


            if (h_count >= 3 || v_count >= 3 || d_count >= 3) {
                return true;
            }
        }
    }
    return false;
}

void initialiseboard(int array[7][9]) {
    int shapes = 6;
    srand(time(0));
    do {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = rand() % shapes;
                cout << array[i][j] << "\t";
            }
            cout << "\n\n";
        }
        removeMatches(array); // Remove matches until there are no matches initially
    } while (hasMatches(array)); // Repeat if there are still matches
}


void drawboard(RenderWindow& window, int array[][9], int selectedRow, int selectedCol) {
    const float adjustedCellSize = cellsize - 10.0f;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            Sprite candysprite;
            candysprite.setTexture(candytextures[array[i][j]]);

            candysprite.setScale(
                adjustedCellSize / candytextures[array[i][j]].getSize().x,
                adjustedCellSize / candytextures[array[i][j]].getSize().y);
            candysprite.setPosition(j * cellsize + 5.0f, i * cellsize + 5.0f);
            if (i == selectedRow && j == selectedCol) {
                candysprite.setColor(Color::Cyan);
            }


            window.draw(candysprite);
        }
    }
}

bool valid(int a[][9], int row1, int col1, int row2, int col2) {
    if (row1==row2 ||col1==col2)
    {
        int temp = a[row1][col1];
        a[row1][col1] = a[row2][col2];
        a[row2][col2] = temp;
        bool valid = hasMatches(a);
        int temp2 = a[row1][col1];
        a[row1][col1] = a[row2][col2];
        a[row2][col2] = temp2;

        return valid;
    }
    return false;

}

void refill(RenderWindow& window, int a[][9]) {
    for (int j = 0; j < cols; j++) {
        int emptySpaces = 0;

        for (int i = rows - 1; i >= 0; i--) {
            if (a[i][j] == -1) {
                emptySpaces++;
            }
        }
        for (int i = emptySpaces - 1; i >= 0; i--) {
            if (a[i][j] == -1) {
                a[i][j] = rand() % 6;
            }
        }
    }
}

bool validswap;

void reshuffleBoard(int array[][9]) {
    srand(time(0));
    do {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                array[i][j] = rand() % 6;
            }
        }
    } while (hasMatches(array));  // Keep reshuffling until matches are found
}

bool swapCandies(RenderWindow& window, int array[][9], int& selectedRow, int& selectedCol, int targetRow, int targetCol, int& moves, Text& movesText, int& score, Text& scoreText) {
    if (array[targetRow][targetCol] == colourBomb) {
        // color bomb
        for (int k = 0; k < rows; k++) {
            array[k][targetCol] = -1;
        }
        for (int j = 0; j < cols; j++) {
            array[targetRow][j] = -1;
        }
        moves--;
        movesText.setString("Moves: " + to_string(moves));
        score += 30;
        scoreText.setString("Score: " + to_string(score));
        if (hasMatches(array)) {
            removeMatches(array);
        }
        validswap = true;
        if (validswap == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if (array[targetRow][targetCol] == speacialcandy) {
        //  special candy
        int a = targetRow;
        int b = targetCol;


        for (int r = a - 1; r <= a + 1; ++r) {
            for (int c = b - 1; c <= b + 1; ++c) {
                if (r >= 0 && r < rows && c >= 0 && c < cols) {
                    array[r][c] = -1;
                }
            }
        }
        moves--;
        movesText.setString("Moves: " + to_string(moves));
        score += 20;
        scoreText.setString("Score: " + to_string(score));
        if (hasMatches(array)) {
            removeMatches(array);
        }
        validswap = true;
        if (validswap == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if ((abs(selectedRow - targetRow) == 1 && selectedCol == targetCol) ||
        (selectedRow == targetRow && abs(selectedCol - targetCol) == 1) ||
        (abs(selectedRow - targetRow) == 1 && abs(selectedCol - targetCol) == 1)) {
        // Valid swap 

        if (valid(array, selectedRow, selectedCol, targetRow, targetCol)) {
            swap(array[selectedRow][selectedCol], array[targetRow][targetCol]);

            if (hasMatches(array)) {
                // Handle matches
                removeMatches(array);

                // Refill and update scores
                refill(window, array);
                selectedRow = -1;
                selectedCol = -1;
                moves--;
                movesText.setString("Moves: " + to_string(moves));
                score += 10;
                scoreText.setString("Score: " + to_string(score));
                validswap = true;
                if (validswap == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else {

                swap(array[selectedRow][selectedCol], array[targetRow][targetCol]);
                reshuffleBoard(array);
            }
        }
    }
    else {
        validswap = false;
        if (validswap == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
}
